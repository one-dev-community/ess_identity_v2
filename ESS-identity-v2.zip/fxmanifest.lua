fx_version 'cerulean'
game 'gta5'

author 'zax & oneshop'
version '1'
description 'OS Scoreboard'
lua54 'yes'

client_script 'loading.lua'

ui_page('html/index.html')

files({
  'html/index.html',
  'html/script.js',
  'html/bootstrap.min.js',
  'html/back.jpg',
  'html/back.png',
  'html/14.png',
  'html/css/nunito-font.css',
  'html/css/style.css',
  'html/css/bootstrap.min.css',
  'html/fonts/Nunito/Nunito-Black.tff',
  'html/fonts/Nunito/Nunito-BlackItalic.tff',
  'html/fonts/Nunito/Nunito-Bold.tff',
  'html/fonts/Nunito/Nunito-BoldItalic.tff',
  'html/fonts/Nunito/Nunito-ExtraBold.tff',
  'html/fonts/Nunito/Nunito-ExtraBoldItalic.tff',
  'html/fonts/Nunito/Nunito-ExtraLight.tff',
  'html/fonts/Nunito/Nunito-ExtraLightItalic.tff',
  'html/fonts/Nunito/Nunito-Italic.tff',
  'html/fonts/Nunito/Nunito-Light.tff',
  'html/fonts/Nunito/Nunito-LightItalic.tff',
  'html/fonts/Nunito/Nunito-Regulat.tff',
  'html/fonts/Nunito/Nunito-SemiBold.tff',
  'html/fonts/Nunito/Nunito-SemiBoldItalic.tff',
})














client_script "@Badger-Anticheat/acloader.lua"